const fetch = require("cross-fetch");
const auth = require("./token.json").access;
const fs = require("fs");
const { URL, APIDIRECTORY, CLIENTID,CLIENTSECRET,REDIRECTURI } = require("./setup.json");
const player = []
// Get Player data
fetch(`https://${URL}${APIDIRECTORY.API.SDVX.player_profile}`, {
    headers: {
        Accept: "application/json",
        Authorization: `bearer ${auth}`
    }
}).then(r => r.json()).then(Response => {
    if(Response.error) return console.log(`Something went wrong! ${Response.error}\nTip: You access token may be invalid or has expired.`);
    console.log(`Sound Voltex ID: ${Response.sdvx_id}`);
    console.log(`Sound Voltex NickName: ${Response.name}`);
    console.log(`Sound Voltex Dan Level: ${Response.skill_level}`);
    player.push({
        "sdvx_id": Response.sdvx_id,
        "name": Response.name,
        "skill_level": Response.skill_level
    })
    fs.writeFile('./player.json', JSON.stringify(player[0]),(err) => {
        if(err) {
            return console.log(`An Error Occured! ${err}`)
        } else {
            return console.log("player.json Saved!");
        }
    })
});

// Get Play History
fetch(`https://kailua.eagle.ac/${APIDIRECTORY.API.SDVX.player_play_history}`, {
    headers: {
        Accept: "application/json",
        Authorization: `bearer ${auth}`
    }
}).then(r => r.json()).then(Response => {
    console.log(`Saving ${player[0].name}'s (${player[0].sdvx_id}) play history.`);
    fs.writeFile("scores.json", JSON.stringify(Response._items), (err) => {
        if(err) {
            return console.log(`An Error Occured! ${err}`)
        } else {
            return console.log("Scores.json Saved!\nDo node JSON2HTML to make a HTML File with your Scores!")
        }
    })
});