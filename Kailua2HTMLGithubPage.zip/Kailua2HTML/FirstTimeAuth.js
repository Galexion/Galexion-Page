const readline = require('readline');
const { stdin: input, stdout: output } = require('process');

const rl = readline.createInterface({ input, output });

rl.question('Have you ever used oAuth2 Before? (y/N)', (answer) => {
    if (answer == "N" || answer == "n" || answer == "no" || answer == "No" || answer == "") {
        console.log("Great! Let's get started.");
        noAuth2Exp()
    } else if (answer == "y" || answer == "yes" || answer == "Y" || answer == "YES" || answer == "Yes") {
        console.log("Great! Let's get started.");
        Auth2Exp()
    }
});

async function noAuth2Exp() {
    console.log("OAuth2 is used with-in everyday internet account systems, from your bank to the Arcade Private Server you use to play Bemani Games.\nO(pen)Auth(orization) is used when Services like Google need to connect your account with 3rd Party's, without just handing over the keys to your house.");
     rl.question('Press Enter to continue.', (answer) => {
        console.log("With-in this use case, We, as in this package of Node.JS Scripts, is the 3rd Party, and Kailua² is the First Party.\nWhat this aims to do, is get your arcade scores, and put them here.");
         rl.question('Press Enter to continue.', (answer) => {
             rl.question('Are you ready to use OAuth2? (y/N)', (answer) => {
                 if (answer == "N" || answer == "n" || answer == "no" || answer == "No" || answer == "") {
                     console.log("No? alright. come back when your ready.");
                     rl.close()
                 } else if (answer == "y" || answer == "yes" || answer == "Y" || answer == "YES" || answer == "Yes") {
                     console.log("Great! Let's get started.");
                     Auth2Exp()
                 }
             })
         });
    });
}

function Auth2Exp() {
    console.log(`alright! lets get started. Anwser the following questions correctly.`);
    rl.question('First, Give me the Kailua² URL (Kailua.your.url). DONT INCLUDE A FORWARD OR BACKWORD SLASH!', (kailuaurl) => {
        rl.question(`Now, head to ${kailuaurl}, sign in if you haven't already, and make a API Client with the Redirect URI of "https://look.here.for.the.code/", and set the scope to settings_read.\nNow, Copy and paste (CTRL + SHFT + V) your CLIENT ID here.`, (CLIENTID) => {
            rl.question(`Now, your CLIENT SECRET.`, (CLIENTSECRET) => {
                console.log(`Now, go to https://${kailuaurl}/oauth/authorize?client_id=${CLIENTID}&redirect_uri=https://look.here.for.the.code/&scope=settings_read&response_type=code and get your code. then go to setup.json and put your CLIENTID and CLIENTSECRET in there. then run node authFromCode with your code that you got from the authorization. After that, Use Score2JSON to get and download your scores and player data, and then use JSON2HTML to turn that data into a HTML File.`);
            });
        });
    });
}