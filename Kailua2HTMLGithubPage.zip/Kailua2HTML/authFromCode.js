const fetch = require('cross-fetch');
const {URL,APIDIRECTORY,CLIENTID,CLIENTSECRET,REDIRECTURI} = require('./setup.json');
const fs = require("fs");
var code = ""
fetch(`https://${URL}${APIDIRECTORY.Oauth.token}?client_id=${CLIENTID}&client_secret=${CLIENTSECRET}&code=${code}&grant_type=authorization_code&redirect_uri=${REDIRECTURI}`).then(r => r.json()).then(Response => {
    if(Response.error) return console.log(`Oh No! Something has gone terribly Wrong! ${Response.error}\nEnsure your code is correct and try again!`);
    let token = {
        "access": Response.access_token,
        "refresh": Response.refresh_token
    }
    fs.writeFile("token.json", JSON.stringify(token), (err) => {
        if (err)
            console.log(err);
        else {
            console.log("Success! Saved tokens as a combo.");
            console.log(`ATTENTION: This token lasts for 1 hour, if you need a refresh, please run node authFromJSON.\nGo generate your score Download with node score2JSON`);
        }
    })
})