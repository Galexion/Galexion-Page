const fetch = require('cross-fetch');
const { URL, APIDIRECTORY, CLIENTID,CLIENTSECRET,REDIRECTURI } = require("./setup.json")
const refresh = require('./setup.json').RefreshToken;
const fs = require("fs");

//Please don't edit this!
fetch(`https://${URL}${APIDIRECTORY.Oauth.token}?client_id=${CLIENTID}&client_secret=${CLIENTSECRET}&refresh_token=${refresh}&grant_type=refresh_token&redirect_uri=https%3A%2F%2F3000-purple-egret-v02r63lq.ws-us18.gitpod.io%2Fapi%2Fdiscord%2Fcallback`).then(r => r.json()).then(Response => {
    if(Response.error) return console.log(`Something went wrong! ${Response.error}\nTip: Your refresh token may be invalid or has expired.`);
    let token = {
        "access": Response.access_token,
        "refresh": Response.refresh_token
    }
    fs.writeFile("token.json", JSON.stringify(token), (err) => {
        if (err)
            console.log(err);
        else {
            console.log("Success! Saved as a token combo. Welcome Back. use authFromJSON.js to use the file instead of authFromRefresh.js");
            console.log(`ATTENTION: This token lasts for 1 hour, if you need a refresh, please run node authFromJSON.`);
        }
    })
});