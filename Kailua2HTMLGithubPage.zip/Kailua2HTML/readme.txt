== Using Kailua²HTML ==

This uses the Kailua² API found in Arcade Cab Private Servers like Project Flower and Eagle.
You Likely got this if you are in one of those community's.

let's go through how to set this thing up.

  / \
 / ! \  Warning!
/_____\

Ensure that NONE of the main files have been tampered with. Go to https://page.galexionlive.ml/secret to check and verify your MD5 matches the .js files provided here.

The settings_read scope includes your Email Address which the unhampered version of Kailua²HTML DOES NOT USE, and hackers may try to use this to log into your account, or worse, something more important than your Game Progress.

Step 1: get Authorized.

Kailua² follows the oAuth2 Authentication Method. Need a Explaination / or need help constructing the authorization URL?
try 'node FirstTimeAuth'!

Step 2: Run the Kailua²HTML Scripts.

Run 'node score2JSON' and 'node JSON2HTML' in that order

Step 3

<404 Step 3 not found>