const fs = require("fs");
const scores = require("./scores.json");
const songs = require("./song_db.json");
const player = require("./player.json")
const connect = []
const html = []

function scores2Songs() {
    for (i = 0; i < scores.length; i++) {
        for (ii = 0; ii < songs.length; ii++) {
            if (scores[i].music_id == songs[ii]._id) {
                let clear_condition = "Crashed";
                if (scores[i].gauge_type === 1 && scores[i].gauge_rate > 0) {
                    clear_condition = "EXC"
                } else if (scores[i].gauge_rate >= 70) {
                    clear_condition = "EC"
                }
                if (scores[i].music_difficulty === 0) { // novice
                    //push metadata to the connect array

                    connect.push({
                        "music_id": songs[ii]._id,
                        "music_name": `${songs[ii].info.title_name} (${songs[ii].info.title_yomigana})`,
                        "music_artist": songs[ii].info.artist_name,
                        "music_difficulty": 'Novice',
                        "music_level": songs[ii].difficulty.novice.difnum,
                        "music_score": scores[i].score,
                        "music_clear": `${clear_condition}, ${scores[i].gauge_rate}%`,
                        "music_date": scores[i].timestamp,
                        "timing": {
                            "critical": scores[i].critical,
                            "near": scores[i].near,
                            "error": scores[i].error,
                            "early": scores[i].early,
                            "late": scores[i].late
                        },
                        "play_id": scores[i]._id
                    })
                } else if (scores[i].music_difficulty === 1) { // advanced
                    //push metadata to the connect array
                    connect.push({
                        "music_id": songs[ii]._id,
                        "music_name": `${songs[ii].info.title_name} (${songs[ii].info.title_yomigana})`,
                        "music_artist": songs[ii].info.artist_name,
                        "music_difficulty": 'Advanced',
                        "music_level": songs[ii].difficulty.advanced.difnum,
                        "music_score": scores[i].score,
                        "music_clear": `${clear_condition}, ${scores[i].gauge_rate}%`,
                        "music_date": scores[i].timestamp,
                        "timing": {
                            "critical": scores[i].critical,
                            "near": scores[i].near,
                            "error": scores[i].error,
                            "early": scores[i].early,
                            "late": scores[i].late
                        },
                        "play_id": scores[i]._id
                    })
                } else if (scores[i].music_difficulty === 2) { // exhaust
                    //push metadata to the connect array
                    connect.push({
                        "music_id": songs[ii]._id,
                        "music_name": `${songs[ii].info.title_name} (${songs[ii].info.title_yomigana})`,
                        "music_artist": songs[ii].info.artist_name,
                        "music_difficulty": 'Exhaust',
                        "music_level": songs[ii].difficulty.exhaust.difnum,
                        "music_score": scores[i].score,
                        "music_clear": `${clear_condition}, ${scores[i].gauge_rate}%`,
                        "music_date": scores[i].timestamp,
                        "timing": {
                            "critical": scores[i].critical,
                            "near": scores[i].near,
                            "error": scores[i].error,
                            "early": scores[i].early,
                            "late": scores[i].late
                        },
                        "play_id": scores[i]._id
                    })
                } else if (scores[i].music_difficulty === 3) {
                    // if the music_difficulty is 3 (inf), find what version from songs
                    let infinite = "null";
                    if (songs[ii].info.inf_ver === 2) {
                        infinite = "infinite"
                    } else if (songs[ii].info.inf_ver === 3) {
                        infinite = "gravity"
                    } else if (songs[ii].info.inf_ver === 4) {
                        infinite = "heavenly"
                    } else if (songs[ii].info.inf_ver === 5) {
                        infinite = "vivid"
                    }
                    //push metadata to the connect array
                    connect.push({
                        "music_id": songs[ii]._id,
                        "music_name": `${songs[ii].info.title_name} (${songs[ii].info.title_yomigana})`,
                        "music_artist": songs[ii].info.artist_name,
                        "music_difficulty": infinite,
                        "music_level": songs[ii].difficulty.infinite.difnum,
                        "music_score": scores[i].score,
                        "music_clear": `${clear_condition}, ${scores[i].gauge_rate}%`,
                        "music_date": scores[i].timestamp,
                        "timing": {
                            "critical": scores[i].critical,
                            "near": scores[i].near,
                            "error": scores[i].error,
                            "early": scores[i].early,
                            "late": scores[i].late
                        },
                        "play_id": scores[i]._id
                    })
                }
            }
        }
        }
    connect2html()
}
function addtoHTML(results, status) {
    return new Promise((resolve, reject) => {
        for (i = 0; i < connect.length; i++) {
            html.push(`<tr id='${connect[i].play_id}'><td>${connect[i].music_name}</td><td>${connect[i].music_artist}</td><td>${connect[i].music_difficulty}</td><td>${connect[i].music_score}</td><td>${connect[i].music_clear}</td><td>Crit: ${connect[i].timing.critical}<br>Near: ${connect[i].timing.near} (${connect[i].timing.early}/${connect[i].timing.late})<br>Error: ${connect[i].timing.error}</td><td>${connect[i].music_date}</td></tr>`)
        }
        resolve();
    })
}
async function connect2html() {
    await addtoHTML().then(response => {
        var html1 = [`<!doctype HTML><html lang="jp"><head><style> table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; } td, th { border: 1px solid #dddddd; text-align: left; padding: 8px; } tr:nth-child(even) { background-color: #dddddd; } </style><meta charset='UTF-8'><title>${player.name}'s Scores</title></head><body><div id='wrapper'><div id='header'><h1>${player.name}'s Scores</h1><br><p>EC = Effective Clear, EXC = Excessive Clear</p></div><table><tr><th>Music</th><th>Artist</th><th>Difficulty</th><th>Score</th><th>Gauge</th><th>Timing</th><th>Date</th></tr>`]
        var html2 = [`</table></div></body></html>`]
        var htmlhalf = html1.concat(html)
        var htmlcomplete = htmlhalf.concat(html2).join("")
            const regex = /[\\"]/gm;
            const subst = ``;
            const result = htmlcomplete
            fs.appendFile('./scores.html', result, err => {
                if (err) {
                    throw err;
                }
            })
    })
}
scores2Songs()